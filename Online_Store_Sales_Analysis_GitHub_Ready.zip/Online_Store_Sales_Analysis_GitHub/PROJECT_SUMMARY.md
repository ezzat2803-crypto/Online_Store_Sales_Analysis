# Case Study: Online Store Sales & Customer Analysis

**Type:** Practice / academic-style portfolio project  
**Service:** Sales and customer data analysis for a small online store  
**Tools:** Python, pandas, matplotlib, Excel

## The problem

A store owner can have a sales spreadsheet but still not know which products bring in the most revenue, when sales were stronger, or how many customers bought more than once.

My goal was to turn practice order data into a short report that is easy to read.

## What I used

A **synthetic retail practice workbook** with 612 raw transaction rows, 30 products and 150 entries in the customer reference table. The workbook included several sales channels, so I focused on the Online channel to match the service.

## My process

1. I checked missing values, duplicates and invalid quantities before calculating anything.
2. I removed 12 exact duplicate order rows from the full dataset and standardized text labels.
3. I selected online orders and excluded flagged returns and invalid transactions from the revenue figures.
4. I matched product categories to orders, analyzed monthly sales and regions, and grouped customers by purchasing behavior.
5. I saved four charts, a cleaned Excel file and a short PDF report with three suggested next steps.

## What I found

- **175** valid, non-returned online orders were analyzed.
- Those orders had a recorded revenue total of **126,657.37** in dataset units.
- **Electronics** represented **71.7%** of online revenue.
- **106** identified customers were found: **59** had one order and **47** had two or more.
- **June 2026** was the strongest month in this dataset.

## What I would recommend

I would review inventory and margins for electronics, test whether one-time customers respond to a follow-up offer, and compare low-sales months with traffic and promotion history. These are **possible next steps**, not measured improvements.

## Limits of the analysis

This is **not a paid client project** and the dataset is **synthetic**. The source does not name a currency, so I don't assign one. Returns are treated as fully excluded from revenue, which would need confirmation in real client work. Customer analysis excludes orders with no customer ID. The rules for customer groups are descriptive, not predictive machine learning.

[View the notebook](notebooks/online_store_sales_analysis.ipynb) | [View the charts](charts/) | [Open the PDF report](deliverables/Sales_Analysis_Report.pdf)
