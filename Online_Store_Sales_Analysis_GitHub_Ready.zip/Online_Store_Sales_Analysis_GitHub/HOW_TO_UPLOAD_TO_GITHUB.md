# Uploading this project to GitHub

1. Extract the ZIP file on your computer. You should see `README.md`, `notebooks`, `data`, `charts`, `outputs`, and `deliverables` inside the project folder.
2. Open [github.com/new](https://github.com/new) while signed in to your account.
3. Set the repository name to `online-store-sales-analysis` (or any name you prefer) and choose **Public**.
4. Click **Create repository**. Then choose **uploading an existing file**.
5. Open the extracted project folder, select **all files and folders inside**, and drag them into GitHub. **Upload the contents of the folder, not the ZIP as a single file.**
6. Write a commit message, such as `Add online store sales analysis project`, and click **Commit changes**.
7. Open your repository page. You should see this README with four chart previews. Open the `.ipynb` notebook and PDF report to check they display.
8. Copy the new public repository URL into your Session 3 assignment as the portfolio link.

If the browser upload struggles with many files, use **GitHub Desktop** and publish the extracted folder instead.

**Portfolio label:** Use `Practice Project | Online Store Sales & Customer Analysis`. Don't describe this as a completed paid job or a result achieved for a real store.
