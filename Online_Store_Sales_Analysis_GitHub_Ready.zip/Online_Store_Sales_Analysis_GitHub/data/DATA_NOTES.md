# Dataset notes

This repository uses a **synthetic retail practice workbook** previously available for a training exercise, not real orders or customer data.

The workbook was exported to three CSV files:

- `orders.csv` — 612 raw rows, including deliberately messy data and multiple sales channels.
- `products.csv` — 30 product-reference records.
- `customers.csv` — 150 customer-reference records (synthetic IDs/names).

Dates were converted from Excel serial values into ISO date strings during export. Other issues such as missing discounts, missing customer IDs, duplicate rows and invalid quantities were kept so the notebook could demonstrate its cleaning decisions.

**Method note:** Product/customer names and monetary amounts are part of the synthetic practice data. The source gives no currency. The analysis only uses rows in `Sales_Channel == 'Online'`. Returned orders are excluded from reported sales revenue, without making claims about actual refunds.
